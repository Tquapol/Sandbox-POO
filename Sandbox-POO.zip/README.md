# Sand Project

Sandbox-POO est un jeu de type bac-à-sable comportant quatre
éléments : Pierre, Eau, Sable et InerSable.

Contrôles :
	1 -> Pierre
	2 -> Eau
	3 -> Sable
	4 -> InerSable
	Espace -> Pause
	G -> Sol
	Shift-X -> Effacer
	Clic gauche -> Dessiner
	Clic droit -> Gommer
	Molette -> Modifier la taille de la brosse

En cas de problème d'exécution due à l'antivirus, modifier
l'accord depuis les paramètres de l'ordinateur.

Un jeu de Klarkifou par Tquapol et Antoine Daniel.
